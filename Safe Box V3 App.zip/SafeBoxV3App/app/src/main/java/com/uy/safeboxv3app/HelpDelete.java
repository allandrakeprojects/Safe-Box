package com.uy.safeboxv3app;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class HelpDelete extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.help_delete);
    }
}