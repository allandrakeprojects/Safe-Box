package com.uy.safeboxv3app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class StatusVault extends AppCompatActivity {

    private ProgressDialog dialog;
    public ImageView IV_VaultStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.status_vault);

        IV_VaultStatus = findViewById(R.id.IV_VaultStatus);

        PhoneStatus();
        RealtimeVaultStatus();
    }

    public void RealtimeVaultStatus() {
        final Intent intent = new Intent(this, StatusVault.class);
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Sensors").child("lockSensor");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String vaultStatus = (String) dataSnapshot.getValue();

                if(vaultStatus.equals("True")) {
                    //unlock image
                    Log.d("Test", "Unlock");
                    IV_VaultStatus.setImageDrawable(getResources().getDrawable(R.drawable.safetitle));
                    dialog.dismiss();

                    // notification
                    NotificationCompat.Builder b = new NotificationCompat.Builder(getApplicationContext());
                    b.setAutoCancel(true)
                            .setDefaults(NotificationCompat.DEFAULT_ALL)
                            .setWhen(System.currentTimeMillis())
                            .setSmallIcon(R.drawable.safetitle)
                            .setTicker("Safe Box Vault")
                            .setContentTitle("Safe Box Vault")
                            .setContentText("Vault Unlocked.");
                    NotificationManager nm = (NotificationManager) getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE);
                    nm.notify(1, b.build());
                } else {
                    //lock image
                    Log.d("Test", "Lock");
                    IV_VaultStatus.setImageDrawable(getResources().getDrawable(R.drawable.safeboxstatus));

                    // notification
                    NotificationCompat.Builder b = new NotificationCompat.Builder(getApplicationContext());
                    b.setAutoCancel(true)
                            .setDefaults(NotificationCompat.DEFAULT_ALL)
                            .setWhen(System.currentTimeMillis())
                            .setSmallIcon(R.drawable.safetitle)
                            .setTicker("Safe Box Vault")
                            .setContentTitle("Safe Box Vault")
                            .setContentText("Vault Locked.");
                    NotificationManager nm = (NotificationManager) getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE);
                    nm.notify(1, b.build());
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // leave blank
            }
        });
    }

    public void PhoneStatus() {

        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Sensors").child("phoneButton");
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String vaultStatus = (String) dataSnapshot.getValue();

                if(vaultStatus.equals("True")) {
                    dialog = new ProgressDialog(StatusVault.this);
                    dialog.setMessage("Unlocking. Please wait...");
                    dialog.show();
                    dialog.setCancelable(true);
                    dialog.setCanceledOnTouchOutside(true);
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // leave blank
            }
        });
    }

    public void unlockpage(View v){
        final Intent intent = new Intent(this, UnlockVault.class);
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Sensors").child("lockSensor");
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String vaultStatus = (String) dataSnapshot.getValue();

                if(vaultStatus.equals("True")) {
                    Toast.makeText(getApplication(), "Safe Box already Unlocked.", Toast.LENGTH_SHORT).show();
                } else {
                    startActivity(intent);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // leave blank
            }
        });
    }
    public void videopage(View v){
        Intent intent = new Intent(this, VideoClips.class);
        startActivity(intent);
    }
    public void helppage(View v){
        Intent intent = new Intent(this, HelpScreen.class);
        startActivity(intent);
    }
    public void logspage(View v){
        Intent intent = new Intent(this, ActivityLogs.class);
        startActivity(intent);
    }

}